# pinball-game
Made with love, Python 3, pygame, pyinstaller, Atom, PyCharm, and Illustrator


e:/python.exe e:/pinball-game/main.py